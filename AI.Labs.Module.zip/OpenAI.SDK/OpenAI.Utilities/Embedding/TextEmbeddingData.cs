﻿namespace OpenAI.Utilities.Embedding;

public class TextEmbeddingData
{
    public string FileName { get; set; }
    public string Text { get; set; }
    public int NToken { get; set; }
}