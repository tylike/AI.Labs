﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle( "WhisperNet" )]
[assembly: AssemblyDescription( "DirectCompute port of whisper.cpp library, C# bindings" )]
[assembly: Guid( "ced6cdb7-e040-4398-bae8-3417e5fa35f1" )]