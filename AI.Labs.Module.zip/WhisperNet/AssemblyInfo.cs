﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCopyright( "Copyright © const.me, 2022-2023" )]
[assembly: ComVisible( false )]
[assembly: AssemblyVersion( "1.12.0.0" )]