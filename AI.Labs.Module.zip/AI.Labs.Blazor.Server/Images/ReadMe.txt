﻿Folder Description

The "Images" project folder is intended for storing custom image files.


Relevant Documentation

Add and Override Images
https://docs.devexpress.com/eXpressAppFramework/112792

Assign a Custom Image
https://docs.devexpress.com/eXpressAppFramework/112744
