﻿//using DevExpress.ExpressApp;
//using DevExpress.Xpo;
//public sealed class LabsSTTModule : ModuleBase
//{
//}
//[NonPersistent]
//public class XPOHolder : XPBaseObject
//{
//    public XPOHolder(Session s) : base(s)
//    {

//    }
//}
